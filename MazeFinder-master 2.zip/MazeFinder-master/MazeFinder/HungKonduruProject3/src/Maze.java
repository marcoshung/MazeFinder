
public class Maze {

}
